package io.github.swapnadeepmohapatra.Parking;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;
import io.github.swapnadeepmohapatra.Parking.R;

public class CarAdapter extends ArrayAdapter<Car> {
    public CarAdapter(Context context, int resource, List<Car> objects) {
        super(context, resource, objects);
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = ((Activity) getContext()).getLayoutInflater().inflate(R.layout.car_item, parent, false);
        }

        final Car car = getItem(position);
        final CheckBox checkBox = convertView.findViewById(R.id.checkBoxCar);

        if (car.isState()) {
            checkBox.setChecked(true);
            checkBox.setEnabled(false);
        } else {
            checkBox.setChecked(false);
            checkBox.setEnabled(true);

            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (checkBox.isChecked()) {
                        checkBox.setChecked(true);
                        checkBox.setEnabled(false);

                        FirebaseDatabase.getInstance().getReference().child("Car").child(car.getId()).child("state").setValue(true).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(getContext(), "Booked", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getContext(), BookedActivity.class);
                                    intent.putExtra("ticket", car.getTicket());
                                    intent.putExtra("id", car.getId());
                                    getContext().startActivity(intent);
                                }
                            }
                        });

                    }
                }
            });

//            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                @Override
//                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//
//                }
//            });
        }
        return convertView;
    }
}

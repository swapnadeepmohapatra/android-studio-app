package io.github.swapnadeepmohapatra.Parking;

public class Car {
    private boolean state;
    private String id;
    private String ticket;

    public Car() {
    }

    public Car(boolean state, String id, String ticket) {
        this.state = state;
        this.id = id;
        this.ticket = ticket;
    }

    public boolean isState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }
}
